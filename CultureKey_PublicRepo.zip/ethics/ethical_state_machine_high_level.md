# Ethical State Machine (High Level)

(placeholder)